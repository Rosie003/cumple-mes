
// Navegación entre secciones
function navigateTo(sectionId) {
    document.querySelectorAll('.section').forEach(section => section.classList.add('hidden'));
    document.getElementById(sectionId).classList.remove('hidden');
}

// Reloj de tiempo
function updateTimer() {
    const startDate = new Date("2023-07-04T18:00:00");
    const now = new Date();
    const diff = now - startDate;

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    document.getElementById('timer').textContent = `${hours} horas, ${minutes} minutos y ${seconds} segundos`;
}
setInterval(updateTimer, 1000);

// CD Playlist
function openPlaylist() {
    window.open("https://music.youtube.com/playlist?list=PLRuq6I04HRdb-nI9BITiqiNzndU8lNWi7&si=_4EtpobsY3aE-cXk", "_blank");
}

// Álbum de fotos
const images = ["img/photo1.jpg", "img/photo2.jpg", "img/photo3.jpg"];
let currentImageIndex = 0;

function showImage(index) {
    document.getElementById("album-image").src = images[index];
}

function nextImage() {
    currentImageIndex = (currentImageIndex + 1) % images.length;
    showImage(currentImageIndex);
}

function prevImage() {
    currentImageIndex = (currentImageIndex - 1 + images.length) % images.length;
    showImage(currentImageIndex);
}
